"""
Dataset Preparation Script for Crop Disease Detection (PlantVillage).
Discovers classes, filters corrupted or duplicate images, creates reproducible
70% Train / 15% Validation / 15% Test splits, and exports class mappings.
"""

import os
import sys
import json
import hashlib
import argparse
import logging
from pathlib import Path
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config import (
    DATASET_RAW_DIR,
    DATASET_SPLIT_DIR,
    CLASS_NAMES_PATH,
    ARTIFACTS_DIR,
    RANDOM_SEED
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


def compute_file_hash(filepath: Path) -> str:
    """Computes MD5 hash for image deduplication."""
    hasher = hashlib.md5()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()


def inspect_and_collect_images(raw_dir: Path):
    """
    Scans class folders, detects duplicates, and validates image readability.
    """
    if not raw_dir.exists():
        raise FileNotFoundError(
            f"Dataset directory '{raw_dir}' does not exist!\n"
            f"Please download the PlantVillage dataset from:\n"
            f"  https://github.com/spMohanty/PlantVillage-Dataset\n"
            f"and extract its class folders into: {raw_dir}"
        )

    class_dirs = [d for d in raw_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]
    if not class_dirs:
        raise ValueError(f"No class subdirectories found inside '{raw_dir}'.")

    class_dirs.sort(key=lambda d: d.name)
    logger.info(f"Discovered {len(class_dirs)} class directories.")

    class_images = defaultdict(list)
    seen_hashes = set()
    total_scanned = 0
    duplicate_count = 0
    corrupt_count = 0

    for cdir in class_dirs:
        cname = cdir.name
        for img_path in cdir.iterdir():
            if img_path.is_file() and img_path.suffix.lower() in SUPPORTED_EXTENSIONS:
                total_scanned += 1
                # Check for readable image
                try:
                    with Image.open(img_path) as img:
                        img.verify()
                except Exception:
                    corrupt_count += 1
                    logger.debug(f"Skipping corrupted image: {img_path}")
                    continue

                # Deduplication check
                fhash = compute_file_hash(img_path)
                if fhash in seen_hashes:
                    duplicate_count += 1
                    continue
                seen_hashes.add(fhash)

                class_images[cname].append(str(img_path.resolve()))

    logger.info(f"Scan complete. Total files scanned: {total_scanned}")
    logger.info(f"Unique valid images: {sum(len(v) for v in class_images.values())}")
    logger.info(f"Duplicates pruned: {duplicate_count}, Corrupt images rejected: {corrupt_count}")

    # Remove any empty classes
    class_images = {k: v for k, v in class_images.items() if len(v) > 0}
    return class_images


def split_dataset(class_images: dict, train_ratio=0.70, val_ratio=0.15, test_ratio=0.15, seed=RANDOM_SEED):
    """
    Creates stratified reproducible splits for each class.
    """
    np.random.seed(seed)
    splits = {"train": {}, "val": {}, "test": {}}

    for cname, files in class_images.items():
        shuffled = list(files)
        np.random.shuffle(shuffled)
        n = len(shuffled)

        n_train = int(np.floor(n * train_ratio))
        n_val = int(np.floor(n * val_ratio))
        # Ensure at least 1 sample in validation and test if class has at least 3 samples
        if n >= 3:
            n_train = max(1, n_train)
            n_val = max(1, n_val)
            n_test = max(1, n - n_train - n_val)
        else:
            n_test = n - n_train - n_val

        train_files = shuffled[:n_train]
        val_files = shuffled[n_train:n_train + n_val]
        test_files = shuffled[n_train + n_val:]

        splits["train"][cname] = train_files
        splits["val"][cname] = val_files
        splits["test"][cname] = test_files

    return splits


def plot_class_distribution(class_images: dict, output_path: Path):
    """
    Generates a class distribution bar chart.
    """
    classes = sorted(list(class_images.keys()))
    counts = [len(class_images[c]) for c in classes]

    # Clean display labels
    labels = [c.replace("___", "\n").replace("_", " ") for c in classes]

    plt.figure(figsize=(14, max(8, len(classes) * 0.35)))
    y_pos = np.arange(len(classes))
    plt.barh(y_pos, counts, color="#2e7d32", edgecolor="#1b5e20", alpha=0.85)
    plt.yticks(y_pos, labels, fontsize=8)
    plt.xlabel("Number of Unique Images", fontsize=10, fontweight="bold")
    plt.title("PlantVillage Dataset - Class Sample Distribution", fontsize=12, fontweight="bold")
    plt.gca().invert_yaxis()
    plt.grid(axis="x", linestyle="--", alpha=0.6)
    plt.tight_layout()

    output_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(str(output_path), dpi=200)
    plt.close()
    logger.info(f"Saved class distribution visualization to '{output_path}'.")


def main():
    parser = argparse.ArgumentParser(description="Prepare and split PlantVillage dataset.")
    parser.add_argument("--data-dir", type=str, default=str(DATASET_RAW_DIR), help="Path to raw dataset.")
    parser.add_argument("--output-dir", type=str, default=str(DATASET_SPLIT_DIR), help="Path to save splits manifest.")
    parser.add_argument("--train-ratio", type=float, default=0.70)
    parser.add_argument("--val-ratio", type=float, default=0.15)
    parser.add_argument("--test-ratio", type=float, default=0.15)
    args = parser.parse_args()

    raw_dir = Path(args.data_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

    logger.info(f"Preparing dataset from: {raw_dir}")
    try:
        class_images = inspect_and_collect_images(raw_dir)
    except Exception as e:
        logger.error(f"Dataset preparation could not continue: {e}")
        sys.exit(1)

    classes = sorted(list(class_images.keys()))
    logger.info(f"Identified {len(classes)} non-empty classes.")

    # Save class_names.json to artifacts directory
    with open(CLASS_NAMES_PATH, "w", encoding="utf-8") as f:
        json.dump(classes, f, indent=2)
    logger.info(f"Saved class mapping ({len(classes)} classes) to '{CLASS_NAMES_PATH}'.")

    # Create splits
    splits = split_dataset(class_images, args.train_ratio, args.val_ratio, args.test_ratio)

    # Save split manifests
    manifest_path = out_dir / "splits_manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(splits, f, indent=2)
    logger.info(f"Saved split manifests to '{manifest_path}'.")

    # Summary report
    summary = {
        "total_classes": len(classes),
        "total_images": sum(len(v) for v in class_images.values()),
        "train_images": sum(len(v) for v in splits["train"].values()),
        "val_images": sum(len(v) for v in splits["val"].values()),
        "test_images": sum(len(v) for v in splits["test"].values()),
        "class_counts": {c: len(class_images[c]) for c in classes}
    }
    with open(out_dir / "dataset_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    # Plot distribution chart
    plot_class_distribution(class_images, ARTIFACTS_DIR / "class_distribution.png")

    logger.info("Dataset preparation successfully completed.")
    logger.info(f"Summary: {summary['total_images']} images partitioned into "
                f"{summary['train_images']} Train, {summary['val_images']} Val, {summary['test_images']} Test.")


if __name__ == "__main__":
    main()
